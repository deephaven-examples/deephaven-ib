"""Generally useful internal functionality not needed in the user-facing API."""
